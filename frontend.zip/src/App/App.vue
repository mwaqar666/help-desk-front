<template>
	<main-layout></main-layout>
</template>

<script lang="ts" src="./App.ts"></script>
