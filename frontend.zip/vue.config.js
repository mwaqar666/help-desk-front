module.exports = {
	transpileDependencies: ["vuetify"],
};
